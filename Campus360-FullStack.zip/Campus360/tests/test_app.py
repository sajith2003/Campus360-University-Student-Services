import unittest, tempfile, subprocess, sys, os, json, time, socket
from pathlib import Path
from urllib.request import build_opener, HTTPCookieProcessor, Request
from urllib.error import HTTPError
from http.cookiejar import CookieJar
ROOT=Path(__file__).resolve().parents[1]
NAME='Campus360'
class Client:
    def __init__(self,base): self.base=base;self.op=build_opener(HTTPCookieProcessor(CookieJar()));self.csrf=''
    def req(self,path,data=None,status=200):
        req=Request(self.base+'/api/'+path,data=None if data is None else json.dumps(data).encode(),headers={'Content-Type':'application/json','X-CSRF':self.csrf})
        try:r=self.op.open(req,timeout=5)
        except HTTPError as e:r=e
        with r: code=r.code;out=json.load(r)
        assert code==status,(path,code,out,status)
        return out
    def login(self,email):
        v=self.req('login',{'email':email,'password':NAME+'123!'});self.csrf=v['csrf'];return v['user']
class Integration(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(); s=socket.socket();s.bind(('127.0.0.1',0));port=s.getsockname()[1];s.close();self.base=f'http://127.0.0.1:{port}'
        self.proc=subprocess.Popen([sys.executable,str(ROOT/'app.py'),'--port',str(port)],env={**os.environ,'APP_DB':str(Path(self.temp.name)/'test.db'),'APP_DEMO':'1'},stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        for _ in range(100):
            try: self.a=Client(self.base);self.a.req('config');break
            except OSError:time.sleep(.05)
        else:self.fail('Server did not start')
        self.b=Client(self.base)
    def tearDown(self):self.proc.terminate();self.proc.wait(timeout=5);self.temp.cleanup()
    def test_auth(self):
        self.a.req('state',status=401);self.a.req('login',{'email':'bad@example.com','password':'wrong'},401);r=self.a.req('register',{'name':'New Test','email':'new@example.com','password':'StrongPass123!'});self.assertEqual(r['user']['role'],'member');self.a.req('state');self.a.req('logout',{},403);self.a.csrf=r['csrf'];self.a.req('logout',{});self.a.req('state',status=401)
    def test_workflow(self):
        a=self.a.login('alex@'+NAME.lower()+'.demo'); b=self.b.login('sam@'+NAME.lower()+'.demo'); cfg=json.loads((ROOT/'project.json').read_text(encoding='utf-8')); title,desc,vals=cfg['seed'][0];d=dict(zip([f['key'] for f in cfg['fields']],vals));from datetime import date,datetime,timedelta
        for f in cfg['fields']:
            if f['type']=='date': d[f['key']]=(date.today()+timedelta(days=30)).isoformat()
            if f['type']=='datetime': d[f['key']]=(datetime.now()+timedelta(days=30)).strftime('%Y-%m-%dT%H:%M')
        d.update(title='New test record',description='Test description');rid=self.a.req('create',d)['id'];self.assertEqual(self.a.req('state')['records'][0]['id'],rid)
        if cfg.get('private'):
            self.assertNotIn(rid,[r['id'] for r in self.b.req('state')['records']]);self.b.req('respond',{'id':rid,'body':'Test'},404);self.a.req('invite',{'id':rid,'email':'sam@'+NAME.lower()+'.demo'})
        self.b.req('status',{'id':rid,'status':cfg['statuses'][-1]},403);self.b.req('respond',{'id':rid,'body':'Test response'});self.b.req('respond',{'id':rid,'body':'Repeat'},409);r=next(x for x in self.a.req('state')['records'] if x['id']==rid);resp=r['responses'][0];self.b.req('decide',{'id':resp['id'],'status':'accepted'},403)
        if cfg['mode']!='campus': self.a.req('decide',{'id':resp['id'],'status':'accepted'})
        self.assertEqual(next(x for x in self.b.req('state')['records'] if x['id']==rid)['mine']['status'],'accepted');self.a.req('status',{'id':rid,'status':cfg['statuses'][-1]});self.assertEqual(next(x for x in self.b.req('state')['records'] if x['id']==rid)['status'],cfg['statuses'][-1]);
        if cfg.get('private'):
            self.a.req('revoke',{'id':rid,'email':'sam@'+NAME.lower()+'.demo'});self.assertNotIn(rid,[r['id'] for r in self.b.req('state')['records']])
if __name__=='__main__':unittest.main()

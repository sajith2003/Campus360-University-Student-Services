from app import *
from datetime import date, datetime
import math
C=json.loads((ROOT/'project.json').read_text(encoding='utf-8'))
NAME=C['name']; PORT=C['port']; PASSWORD=NAME+'123!'; MODE=C['mode']; PRIVATE=C.get('private',False)
ROLE=C.get('publish_role','officer' if C.get('moderate') else 'member')
ACCOUNTS=[('Alex Morgan','alex@'+NAME.lower()+'.demo',ROLE),('Sam Lee','sam@'+NAME.lower()+'.demo','member'),('Workspace admin','admin@'+NAME.lower()+'.demo','admin')]
SCHEMA='''CREATE TABLE IF NOT EXISTS records(id INTEGER PRIMARY KEY,owner INTEGER NOT NULL REFERENCES users(id),title TEXT NOT NULL,description TEXT NOT NULL,details TEXT NOT NULL,status TEXT NOT NULL,created TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS responses(id INTEGER PRIMARY KEY,record INTEGER NOT NULL REFERENCES records(id),sender INTEGER NOT NULL REFERENCES users(id),body TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'pending',created TEXT NOT NULL,UNIQUE(record,sender));
CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY,record INTEGER NOT NULL REFERENCES records(id),actor INTEGER NOT NULL REFERENCES users(id),body TEXT NOT NULL,created TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS shares(record INTEGER NOT NULL REFERENCES records(id),member INTEGER NOT NULL REFERENCES users(id),PRIMARY KEY(record,member));'''
def on_register(c,uid): pass
def log(c,r,u,body): c.execute('INSERT INTO events(record,actor,body,created) VALUES(?,?,?,?)',(r,u,body,now()))
def seed(c,ids):
    for i,(title,desc,vals) in enumerate(C['seed']):
        owner=ids[0] if i==0 or PRIVATE or MODE=='donor' else ids[1]
        rid=c.execute('INSERT INTO records(owner,title,description,details,status,created) VALUES(?,?,?,?,?,?)',(owner,title,desc,json.dumps(dict(zip([f['key'] for f in C['fields']],vals))),C['statuses'][0],now())).lastrowid
        log(c,rid,owner,'Created demo record')
        if PRIVATE and i==1: c.execute('INSERT INTO shares VALUES(?,?)',(rid,ids[1]))
def validate(d):
    v={}
    for f in C['fields']:
        k=f['key']; t=f['type']; x=d.get(k)
        if t in ('integer','money','percent','lat','lon'):
            require(type(x) in (int,float) and math.isfinite(x),f'Invalid {f["label"]}',400)
            lo,hi={'integer':(1,100000),'money':(0,1000000000),'percent':(0,100),'lat':(-90,90),'lon':(-180,180)}[t]
            require(lo<=x<=hi and (t!='integer' or type(x)==int),f'Invalid {f["label"]}',400)
            v[k]=x
        else:
            x=field(d,k,400)
            if t=='choice': require(x in f['options'],'Invalid choice',400)
            if t=='date': date.fromisoformat(x)
            if t=='datetime': require(datetime.fromisoformat(x).tzinfo is None,'Use local date and time.',400)
            if t=='github': require(re.fullmatch(r'https://github\.com/[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+/?',x),'Use a GitHub repository URL.',400)
            v[k]=x
    return v
def visible(c,r,u): return not PRIVATE or r['owner']==u['id'] or bool(one(c,'SELECT 1 FROM shares WHERE record=? AND member=?',(r['id'],u['id'])))
def manage(r,u): return r['owner']==u['id'] or (not PRIVATE and u['role']=='admin') or (C.get('moderate') and u['role']=='officer')
def within_deadline(details):
    # Date/time fields use the server's local calendar in this local prototype.
    if MODE in ('food','campus'):
        k='until' if MODE=='food' else 'when'; t=datetime.fromisoformat(details[k]); require(t.tzinfo is None,'Use local date and time.',400);return t>=datetime.now()
    if 'deadline' in details: return date.fromisoformat(details['deadline'])>=date.today()
    return True
def can_create(u): return not C.get('publish_role') or u['role'] in (C['publish_role'],'admin')
def enrich(c,r,u):
    r['details']=json.loads(r['details']); r['can_manage']=manage(r,u); r['can_respond']=r['owner']!=u['id'] and r['status']==C['statuses'][0] and within_deadline(r['details']);
    rr=rows(c,'SELECT responses.*,users.name AS sender_name FROM responses JOIN users ON users.id=sender WHERE record=? ORDER BY responses.id DESC',(r['id'],)); r['responses']=[x for x in rr if r['can_manage'] or x['sender']==u['id']]; r['accepted']=sum(x['status']=='accepted' for x in rr); r['mine']=next((x for x in rr if x['sender']==u['id']),None)
    r['history']=rows(c,'SELECT events.body,events.created FROM events WHERE record=? ORDER BY id DESC',(r['id'],)) if r['can_manage'] or PRIVATE or MODE=='route' else []
    if PRIVATE and r['can_manage']: r['members']=rows(c,'SELECT users.name,users.email FROM shares JOIN users ON users.id=member WHERE record=?',(r['id'],))
    return r
def handle(c,u,method,path,d):
    a=path.removeprefix('/api/'); uid=u['id']
    if method=='GET' and a=='state':
        rec=[enrich(c,r,u) for r in rows(c,'SELECT records.*,users.name AS owner_name FROM records JOIN users ON users.id=owner ORDER BY records.id DESC') if visible(c,r,u)]
        return {'records':rec,'can_create':can_create(u)}
    require(method=='POST','Not found.',404)
    if a=='create':
        require(can_create(u)); details=validate(d); title=field(d,'title',100); desc=field(d,'description',1200)
        rid=c.execute('INSERT INTO records(owner,title,description,details,status,created) VALUES(?,?,?,?,?,?)',(uid,title,desc,json.dumps(details),C['statuses'][0],now())).lastrowid; log(c,rid,uid,'Record created');return {'id':rid}
    if a=='decide':
        x=one(c,'SELECT * FROM responses WHERE id=?',(num(d,'id'),));require(x,'Response not found.',404);r=one(c,'SELECT * FROM records WHERE id=?',(x['record'],));require(visible(c,r,u) and manage(r,u));require(x['status']=='pending','Already reviewed.',409)
        status=field(d,'status',15);require(status in ('accepted','declined'),'Invalid decision',400)
        if status=='accepted':
            require(r['status']==C['statuses'][0],'Record is not open.',409); details=json.loads(r['details']); require(within_deadline(details),'Deadline has passed.',409); accepted=one(c,"SELECT count(*) AS n FROM responses WHERE record=? AND status='accepted'",(r['id'],))['n'];cap=1 if C.get('exclusive') else details.get('places',details.get('capacity',100000));require(accepted<cap,'No spaces remain.',409)
            if C.get('exclusive'): c.execute('UPDATE records SET status=? WHERE id=?',(C['statuses'][1],r['id']))
        c.execute('UPDATE responses SET status=? WHERE id=?',(status,x['id']));log(c,r['id'],uid,'Response '+status);return {'ok':True}
    r=one(c,'SELECT * FROM records WHERE id=?',(num(d,'id'),)); require(r and visible(c,r,u),'Record not found.',404)
    if a=='respond':
        require(r['owner']!=uid,'Cannot respond to your own record.',400);require(r['status']==C['statuses'][0],'Record is not open.',409)
        body=field(d,'body',500); details=json.loads(r['details']); require(within_deadline(details),'Deadline has passed.',409); status='pending'
        if MODE=='campus':
            n=one(c,"SELECT count(*) AS n FROM responses WHERE record=? AND status='accepted'",(r['id'],))['n'];require(n<details['capacity'],'Event is full.',409);status='accepted'
        c.execute('INSERT INTO responses(record,sender,body,status,created) VALUES(?,?,?,?,?)',(r['id'],uid,body,status,now()));return {'ok':True}
    if a=='withdraw':
        x=one(c,'SELECT * FROM responses WHERE record=? AND sender=?',(r['id'],uid));require(x,'Response not found.',404);require(x['status']=='pending' or MODE=='campus','Cannot withdraw an approved response.',409);c.execute('DELETE FROM responses WHERE id=?',(x['id'],));return {'ok':True}
    require(manage(r,u))
    if a=='status':
        s=field(d,'status',40);require(s in C['statuses'],'Invalid status.',400)
        if MODE=='route' and s!='reported': require(u['role'] in ('officer','admin'),'Officer review required.')
        if C.get('exclusive') and s=='reserved':require(one(c,"SELECT 1 FROM responses WHERE record=? AND status='accepted'",(r['id'],)),'Approve a collection request first.',409)
        if C.get('exclusive') and s=='collected':require(r['status']=='reserved','Reserve the offer first.',409)
        if C.get('exclusive') and s=='available':require(r['status']=='available','Cannot reopen a reserved or collected offer.',409)
        c.execute('UPDATE records SET status=? WHERE id=?',(s,r['id']));log(c,r['id'],uid,'Status: '+s);return {'ok':True}
    if a=='update':
        details=validate(d); cap=details.get('places',details.get('capacity'));
        if cap is not None: require(cap>=one(c,"SELECT count(*) AS n FROM responses WHERE record=? AND status='accepted'",(r['id'],))['n'],'Capacity cannot be lower than accepted responses.',409)
        c.execute('UPDATE records SET details=?,title=?,description=? WHERE id=?',(json.dumps(details),field(d,'title',100),field(d,'description',1200),r['id']));log(c,r['id'],uid,'Details updated');return {'ok':True}
    if a=='invite' and PRIVATE:
        require(r['owner']==uid);member=one(c,'SELECT id FROM users WHERE email=?',(field(d,'email',160).lower(),));require(member and member['id']!=uid,'Use an existing member email.',400);c.execute('INSERT OR IGNORE INTO shares VALUES(?,?)',(r['id'],member['id']));log(c,r['id'],uid,'Workspace access granted');return {'ok':True}
    if a=='revoke' and PRIVATE:
        require(r['owner']==uid);c.execute('DELETE FROM shares WHERE record=? AND member IN (SELECT id FROM users WHERE email=?)',(r['id'],field(d,'email',160).lower()));log(c,r['id'],uid,'Workspace access revoked');return {'ok':True}
    raise Err(404,'Unknown action.')

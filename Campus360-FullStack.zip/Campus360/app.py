import os, sqlite3, secrets, hashlib, hmac, json, time, re, mimetypes, argparse
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from http.cookies import SimpleCookie
from urllib.parse import urlsplit
from datetime import datetime, timezone
import sys
sys.modules["app"] = sys.modules[__name__]
# domain imported after utility definitions
ROOT=Path(__file__).resolve().parent
DB=Path(os.environ.get('APP_DB',ROOT/'data'/'app.db'))
DEMO=os.environ.get('APP_DEMO','1')=='1'
class DBConn(sqlite3.Connection):
    def __exit__(self,*args):
        try: return super().__exit__(*args)
        finally: self.close()
def db():
    DB.parent.mkdir(parents=True,exist_ok=True)
    c=sqlite3.connect(DB,timeout=10,factory=DBConn); c.row_factory=sqlite3.Row; c.execute('PRAGMA foreign_keys=ON'); return c
def now(): return datetime.now(timezone.utc).isoformat(timespec='seconds')
def rows(c,q,p=()): return [dict(r) for r in c.execute(q,p)]
def one(c,q,p=()):
    r=c.execute(q,p).fetchone(); return dict(r) if r else None
class Err(Exception):
    def __init__(self,s,m): self.s=s; self.m=m
def require(ok,msg='Permission denied.',status=403):
    if not ok: raise Err(status,msg)
def field(d,k,maxlen=160,minlen=1):
    v=d.get(k,''); require(isinstance(v,str),f'Invalid {k}.',400); v=v.strip(); require(minlen<=len(v)<=maxlen,f'{k}: use {minlen}–{maxlen} characters.',400); return v
def num(d,k,lo=1,hi=1000000000):
    v=d.get(k); require(type(v)==int and lo<=v<=hi,f'Invalid {k}.',400); return v
def pw_hash(p):
    salt=secrets.token_hex(16); return salt+':'+hashlib.pbkdf2_hmac('sha256',p.encode(),bytes.fromhex(salt),250000).hex()
def pw_ok(p,h):
    salt,digest=h.split(':'); return hmac.compare_digest(digest,hashlib.pbkdf2_hmac('sha256',p.encode(),bytes.fromhex(salt),250000).hex())
def add_user(c,name,email,pw,role='member'):
    return c.execute('INSERT INTO users(name,email,password,role) VALUES(?,?,?,?)',(name,email,pw_hash(pw),role)).lastrowid
import domain as D
def init():
    with db() as c:
        c.execute('PRAGMA journal_mode=WAL'); c.executescript('''CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,name TEXT NOT NULL,email TEXT UNIQUE COLLATE NOCASE NOT NULL,password TEXT NOT NULL,role TEXT NOT NULL DEFAULT 'member'); CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY,user_id INTEGER NOT NULL REFERENCES users(id),csrf TEXT NOT NULL,expires INTEGER NOT NULL); CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY);'''+D.SCHEMA)
        if not one(c,"SELECT key FROM meta WHERE key='initialized'"):
            if DEMO:
                ids=[add_user(c,n,e,D.PASSWORD,r) for n,e,r in D.ACCOUNTS]; D.seed(c,ids)
            c.execute("INSERT INTO meta VALUES('initialized')")
def public_user(c,uid): return one(c,'SELECT id,name,email,role FROM users WHERE id=?',(uid,))
class Handler(BaseHTTPRequestHandler):
    def send_data(self,status,body,ct='application/json; charset=utf-8',cookie=None):
        if isinstance(body,dict) or isinstance(body,list): body=json.dumps(body,ensure_ascii=False).encode()
        self.send_response(status); self.send_header('Content-Type',ct); self.send_header('Content-Length',str(len(body))); self.send_header('X-Content-Type-Options','nosniff'); self.send_header('X-Frame-Options','DENY'); self.send_header('Referrer-Policy','no-referrer'); self.send_header('Cache-Control','no-store'); self.send_header('Content-Security-Policy',"default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
        if cookie: self.send_header('Set-Cookie',cookie)
        self.end_headers(); self.wfile.write(body)
    def do_GET(self): self.handle_req('GET')
    def do_POST(self): self.handle_req('POST')
    def handle_req(self,method):
        try:
            path=urlsplit(self.path).path
            if method=='GET' and path in ('/','/app.js','/domain.js','/style.css','/favicon.svg'):
                f=ROOT/'public'/('index.html' if path=='/' else path[1:]); return self.send_data(200,f.read_bytes(),mimetypes.guess_type(f.name)[0] or 'text/plain')
            require(path.startswith('/api/'),'Not found.',404)
            data={}
            if method=='POST':
                require(self.headers.get('Content-Type','').split(';')[0]=='application/json','JSON required.',415)
                length=int(self.headers.get('Content-Length','0')); require(0<length<=1500000,'Invalid request size.',413)
                try: data=json.loads(self.rfile.read(length))
                except (ValueError,UnicodeError): raise Err(400,'Invalid JSON.')
                require(isinstance(data,dict),'Object required.',400)
                origin=self.headers.get('Origin'); host=self.headers.get('Host'); require(not origin or origin in ('http://'+str(host),'https://'+str(host)),'Invalid origin.')
            with db() as c:
                if method=='POST': c.execute('BEGIN IMMEDIATE')
                cookie=SimpleCookie(self.headers.get('Cookie','')); token=cookie['sid'].value if 'sid' in cookie else ''
                sess=one(c,'SELECT * FROM sessions WHERE token=? AND expires>?',(token,int(time.time())))
                u=public_user(c,sess['user_id']) if sess else None
                if path=='/api/config' and method=='GET': return self.send_data(200,{'name':D.NAME,'demo':DEMO,'accounts':[{'name':n,'email':e,'role':r} for n,e,r in D.ACCOUNTS] if DEMO else [],'password':D.PASSWORD if DEMO else None})
                if path in ('/api/login','/api/register') and method=='POST':
                    email=field(data,'email',160).lower(); require(re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',email),'Invalid email.',400); pw=field(data,'password',128,1)
                    if path.endswith('register'):
                        require(len(pw)>=10,'Password needs at least 10 characters.',400); require(not one(c,'SELECT id FROM users WHERE email=?',(email,)),'Email already registered.',409); uid=add_user(c,field(data,'name',80,2),email,pw); D.on_register(c,uid)
                    else:
                        r=one(c,'SELECT * FROM users WHERE email=?',(email,)); require(r and pw_ok(pw,r['password']),'Incorrect email or password.',401); uid=r['id']
                    if sess: c.execute('DELETE FROM sessions WHERE token=?',(token,))
                    c.execute('DELETE FROM sessions WHERE expires<=?',(int(time.time()),)); token=secrets.token_urlsafe(32); csrf=secrets.token_urlsafe(24); c.execute('INSERT INTO sessions VALUES(?,?,?,?)',(token,uid,csrf,int(time.time())+86400)); c.commit(); return self.send_data(200,{'user':public_user(c,uid),'csrf':csrf},cookie=f'sid={token}; Path=/; HttpOnly; SameSite=Strict; Max-Age=86400'+('; Secure' if os.environ.get('SECURE_COOKIE')=='1' else ''))
                if path=='/api/me' and method=='GET': return self.send_data(200,{'user':u,'csrf':sess['csrf'] if sess else None})
                require(u,'Sign in first.',401)
                if method=='POST': require(hmac.compare_digest(self.headers.get('X-CSRF',''),sess['csrf']),'Invalid session token.')
                if path=='/api/logout' and method=='POST':
                    c.execute('DELETE FROM sessions WHERE token=?',(token,)); c.commit(); return self.send_data(200,{'ok':True},cookie='sid=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0')
                result=D.handle(c,u,method,path,data); c.commit(); self.send_data(200,result)
        except Err as e: self.send_data(e.s,{'error':e.m})
        except sqlite3.IntegrityError: self.send_data(409,{'error':'This action conflicts with an existing record.'})
        except (ValueError,TypeError): self.send_data(400,{'error':'Invalid input.'})
        except Exception:
            import traceback; traceback.print_exc(); self.send_data(500,{'error':'Unexpected server error.'})
if __name__=='__main__':
    parser=argparse.ArgumentParser(); parser.add_argument('--port',type=int,default=D.PORT); parser.add_argument('--host',default='127.0.0.1'); parser.add_argument('--init-only',action='store_true'); args=parser.parse_args(); init()
    if not args.init_only:
        print(f'{D.NAME}: http://{args.host}:{args.port}',flush=True); ThreadingHTTPServer((args.host,args.port),Handler).serve_forever()

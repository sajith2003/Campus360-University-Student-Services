# Campus360

**One campus. More possibilities.**

Discover campus events, reserve a place, and track your registrations.

## Run on Windows
Extract, open this folder in VS Code and run `python app.py` (or double-click START_WINDOWS.bat). Requires Python 3.10+; no third-party packages. Open http://127.0.0.1:8010. SQLite initializes automatically.

## Demo accounts
- alex@campus360.demo — member, owns initial records
- sam@campus360.demo — member
- admin@campus360.demo — administrator

Password: `Campus360123!`

## Walkthrough
1. Sign in as Alex and explore seeded records.
2. Create a campus event using the validated form.
3. Sign in as Sam in another browser profile and send a response (private apps: Alex must invite Sam first using Share access).
4. Return to Alex and approve or decline a response, change status, or edit details. Campus registrations reserve immediately subject to capacity.
5. Explore Insights and the activity timeline.

## Data fields
- Category
- Venue
- Event date and time
- Available places

## Architecture
HTML/CSS/JavaScript frontend, Python standard-library HTTP server and JSON API, SQLite. Cookie sessions, CSRF tokens, parameterized SQL, PBKDF2 password hashing, record permissions and validation.

## Theme
Royal blue & coral: #314dab, #a13d4b, #f8f9ff, #dce5ff, #ffdfe0, #e7e2ff.

## Tests
`python -m unittest discover -s tests -v`

## Limitations
Independent campus prototype; events are not affiliated with any university unless explicitly confirmed by the organiser.

Local portfolio prototype using a shared application foundation; no external AI, live integrations, email, SMS, uploaded images or official data verification. Demo records are fictional. Browser interactions and Docker deployment have not been tested. Do not expose demo server to the public internet. Production requires HTTPS, secure cookies, rate limiting, audit/privacy review, a production server and account verification.

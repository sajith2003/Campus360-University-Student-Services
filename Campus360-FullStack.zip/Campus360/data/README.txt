SQLite initializes automatically at first launch.
